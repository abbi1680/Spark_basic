package com.sesh.bda.scala.train.ScalaPractise

object MyObject {

  def main(args: Array[String]): Unit=

  {

    println(" Test ")

 val myClass =  new MyClass("Helo" , 2)

    println(myClass) ;

  }

}
