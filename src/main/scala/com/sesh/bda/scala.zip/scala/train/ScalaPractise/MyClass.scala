package com.sesh.bda.scala.train.ScalaPractise

/**
  * Created by sreej on 05/05/2017.
  */
class MyClass(val param1: String, val param2: Int) {
  // body of class goes here, including the constructor
}