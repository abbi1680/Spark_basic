package com.sesh.bda.scala.common

object Test extends App {
  println("This is a test")
  val x = 5
  println("value of x is " + x)
}